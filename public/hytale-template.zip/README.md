# Hytale Mod Template

A complete, production-ready template for developing Hytale server mods with Gradle 9.2.1, Java 25, and comprehensive documentation.

## Features

- ✨ **Modern Build System** - Gradle 9.2.1 with cross-platform support
- 📚 **Complete API Reference** - Comprehensive documentation of Hytale's server API
- 🎯 **IDE Integration** - Ready-to-go configurations for IntelliJ, VSCode, Eclipse
- 🔧 **Early Plugins** - Support for bytecode transformation (Bootstrap plugins)
- 🚀 **Performance Guides** - Advanced optimization techniques included
- 🌍 **Multiplayer Focus** - Server-side modding (Hytale architecture)

## Documentation

This template includes extensive documentation:

- **[API Reference](docs/HYTALE_API_REFERENCE.md)** - Complete Hytale Server Plugin API documentation
- **[Early Plugins Guide](docs/ADVANCED_EARLY_PLUGINS.md)** - Bootstrap plugins and bytecode transformation
- **[Performance Optimization](docs/PERFORMANCE_OPTIMIZATIONS.md)** - Advanced performance tuning techniques

## Quick Start

### Prerequisites

- Java 25+
- Hytale (installed via official launcher)
- Gradle (included via wrapper)

### Installation

```bash
# Extract or clone this template
cd your-mod-name

# Edit gradle.properties with your mod details
# Edit src/main/resources/manifest.json if needed

# Build the mod
./gradlew build

# Run server
./gradlew runServer
```

## Configuration

### 1. Edit gradle.properties

```properties
group=dev.yourname
name=YourModName
version=1.0.0
java_version=25
mod_description=Description of your mod
website=https://your-website.com
server_version=*
game_build=latest
entry_point=dev.yourname.YourMainPluginClass
```

### 2. Create Your Plugin

Edit `src/main/java/dev/hytalemodding/ExamplePlugin.java`:

```java
package dev.yourname;

import com.hypixel.hytale.server.core.plugin.JavaPlugin;
import com.hypixel.hytale.server.core.plugin.JavaPluginInit;
import javax.annotation.Nonnull;

public class YourMod extends JavaPlugin {

    public YourMod(@Nonnull JavaPluginInit init) {
        super(init);
    }

    @Override
    protected void setup() {
        // Register commands and events here
        getCommandRegistry().registerCommand(
            new MyCommand("hello", "Says hello")
        );
    }

    @Override
    protected void start() {
        super.start();
        getLogger().info("YourMod started!");
    }

    @Override
    protected void shutdown() {
        getLogger().info("YourMod shutting down...");
    }
}
```

## Gradle Tasks

### Build Tasks
```bash
./gradlew build          # Build the mod JAR
./gradlew jar            # Build JAR only
./gradlew clean          # Clean build outputs and remove mod JARs
```

### Hytale Tasks
```bash
./gradlew runServer      # Start Hytale server with mod
./gradlew runClient      # Launch official Hytale launcher
./gradlew copyJar        # Copy mod to official mods directory
./gradlew copyMod        # Copy mod to Hytale mods directory
./gradlew downloadAssets # Copy Assets.zip locally
```

### IDE Tasks
```bash
./gradlew ide            # Generate all IDE configurations
./gradlew vscode         # Generate VSCode configurations
./gradlew eclipse        # Generate Eclipse configurations
```

## Project Structure

```
your-mod/
├── docs/                           # Documentation
│   ├── HYTALE_API_REFERENCE.md     # Complete API documentation
│   ├── ADVANCED_EARLY_PLUGINS.md   # Bootstrap/bytecode transformation
│   └── PERFORMANCE_OPTIMIZATIONS.md # Performance tuning guide
├── src/main/java/dev/yourname/
│   ├── YourMod.java                # Main plugin class
│   ├── commands/                   # Your commands
│   └── events/                     # Your event handlers
├── src/main/resources/
│   └── manifest.json               # Mod manifest
├── build.gradle                    # Build configuration
├── gradle.properties               # Mod properties
├── settings.gradle                 # Project settings
├── gradlew                         # Unix Gradle wrapper
└── gradlew.bat                     # Windows Gradle wrapper
```

## Hytale Architecture

**Important:** Hytale uses a unified server-side mod architecture:

- ✅ All mods are **server-side Java plugins**
- ✅ Client does NOT load mods directly
- ✅ Singleplayer uses an embedded server
- ✅ No client-side modding API exists

This means:
- **Server testing:** Use `./gradlew runServer`
- **Singleplayer testing:** Use `./gradlew runClient` (launches official launcher)
- Mods load from `mods/` directory (relative to server working directory)

## Example: Creating a Command

```java
import com.hypixel.hytale.server.core.command.system.basecommands.CommandBase;
import com.hypixel.hytale.server.core.command.system.CommandContext;
import com.hypixel.hytale.server.core.Message;
import javax.annotation.Nonnull;

public class MyCommand extends CommandBase {
    public MyCommand(String name, String description) {
        super(name, description);
    }

    @Override
    protected void executeSync(@Nonnull CommandContext context) {
        context.sendMessage(Message.raw("Hello from YourMod!"));
    }
}
```

Register in your plugin's `setup()` method:
```java
getCommandRegistry().registerCommand(new MyCommand("hello", "Says hello"));
```

## Example: Handling Events

```java
import com.hypixel.hytale.server.core.event.events.player.PlayerReadyEvent;

public class MyEventHandler {
    public static void onPlayerReady(PlayerReadyEvent event) {
        var player = event.getPlayer();
        player.sendMessage(Message.raw("Welcome to the server!"));
    }
}
```

Register in your plugin's `setup()` method:
```java
getEventRegistry().registerGlobal(
    PlayerReadyEvent.class,
    MyEventHandler::onPlayerReady
);
```

## Advanced Features

### Early Plugins (Bytecode Transformation)

For advanced use cases, you can create Bootstrap plugins that transform classes as they load:

```java
import com.hypixel.hytale.plugin.early.ClassTransformer;

public class MyTransformer implements ClassTransformer {
    @Override
    public byte[] transform(String className, String classLoaderName, byte[] classBytes) {
        // Transform classes here
        return classBytes;
    }

    @Override
    public int priority() {
        return 0;
    }
}
```

⚠️ **Warning:** Early plugins are extremely powerful and should only be used when absolutely necessary. See [Early Plugins Guide](docs/ADVANCED_EARLY_PLUGINS.md) for details.

## License

This template is available under the **CC0 License** - feel free to use it however you like!

## Links

- **Hytale Modding Discord:** https://discord.gg/hytalemodding
- **Hytale Official Documentation:** https://hytale.com/documentation
- **Template Generator:** https://hytale-template.vercel.app

---

**Built for the Hytale modding community**
